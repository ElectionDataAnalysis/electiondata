# results_analysis

## Set-up

### Docker
Docker must be installed on your system.

### .gitignore
Folders you will need in your local repo:
`code/local_data` holds your state-by-state data. Each state has a subfolder, e.g., `code/local_data/NC` for North Carolina. Each state subfolder has two subfolders, one for source data files (`code/local_data/NC/data`) and one for metadata files (`code/local_data/NC/meta`)

`code/local_logs` will receive log files as the program runs.

Other folders are optional, e.g., `local`.

## How to run the app

The following may need to be modified for your operating system. 

### On MacOS 
#### Start the servers
Using Terminal, navigate to the `code` directory. Run `docker-compose up`:

    `$ docker-compose up
    Creating network "code_default" with the default driver
    Creating code_web_1 ... done
    Creating code_db_1  ... done
    Attaching to code_web_1, code_db_1`

This Terminal window will show messages from the web and db servers.

#### Run the application
In a web browser, navigate to `localhost:5000`

#### Stop the application
In a second Terminal window, navigate to the `code` directory. Run `docker-compose down`:

    `$ docker-compose down
    Stopping code_db_1  ... done
    Stopping code_web_1 ... done
    Removing code_db_1  ... done
    Removing code_web_1 ... done
    Removing network code_default
    $`

## Getting to the container command line
For example, to get a bash command line inside the postgres container image:
    `MacBook-Pro-3:code Steph-Airbook$ docker container ls
    CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                    NAMES
    21ba1253b28c        postgres:11         "docker-entrypoint.s…"   14 seconds ago      Up 13 seconds       0.0.0.0:5432->5432/tcp   code_db_1
    cef03ffb9daa        code_web            "flask run"              14 seconds ago      Up 13 seconds       0.0.0.0:5000->5000/tcp   code_web_1
    MacBook-Pro-3:code Steph-Airbook$ docker exec -i -t 21ba1253b28c /bin/bash
`

## docs folder
The `docs` folder has documentation for local set-up of programs and packages that are likely to be useful for dev.

# Code components

## Docker files

### `code/requirements.txt`
Specifies necessary python packages that are not part of the standard python distribution

### `code/docker-compose.yml`
Defines two services: `db` (postgres to store data) and `web` (serves up web content). 

### `code/Dockerfile`
- Imports python and packages listed in `requirements.txt`
- specifies the python file (`app.py`) defining the content served by Flask to the web browser
- starts the web server via Flask



### `code/local_data` folder
Contains one subfolder for each state, each containing three folders:
* `data` containing data files 
* `meta` containing metadata files for the `data` files
* `context` containing necessary state-specific information from sources other than the data files

Also contains a subfolder `tmp` to hold temporary cleaned files for upload to db

### About the `context` folder
This folder contains contextual information about a particular state. This information may be common to many datafiles; it may be related to information in the datafile but may require some contextual knowledge outside of any particular datafile. For example, the fact that the election on 2018-11-06 in North Carolina was a `general` election is contextual knowledge.

- DB elements that must be loaded from the `context` file (or corresponding attribute of state or datafile) before individual records in datafile are addressed: `election`, `reportingunit` , `party`, `office` 
- DB elements that must be loaded from each record in the datafile: `reportingunit` (type of reporting unit will need to be respected, e.g., `county` or `geoprecinct` or `other`)

### About the `CDF_schema_def_info` folder:
 - Contains folder `enumerations` with the various enumerations from the Common Data Format
 - Contains file `tables.txt` with the python dictionary determining the tables in the postgres common data format schema.

## Naming conventions

### Strings used as names and dictionary keys
Each element (each election, candidate, reporting unit, etc.) has a name -- a character string used in the `name` field in the corresponding database table, and also used in the files in the `context`  folder as keys in python dictionaries containing more info about the element.
