--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE election_data_analysis;
--
-- Name: election_data_analysis; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE election_data_analysis WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE election_data_analysis OWNER TO postgres;

\connect election_data_analysis

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: BallotMeasureContest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BallotMeasureContest" (
    "Id" integer,
    "ElectionDistrict_Id" integer,
    "Election_Id" integer,
    CONSTRAINT "bmcon_ElectionDistrict_Id_not_null" CHECK (("ElectionDistrict_Id" IS NOT NULL)),
    CONSTRAINT "bmcon_Election_Id_not_null" CHECK (("Election_Id" IS NOT NULL))
);


ALTER TABLE public."BallotMeasureContest" OWNER TO postgres;

--
-- Name: BallotMeasureSelection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BallotMeasureSelection" (
    "Name" character varying,
    "Id" integer,
    CONSTRAINT "bmsel_Name_not_null" CHECK (("Name" IS NOT NULL))
);


ALTER TABLE public."BallotMeasureSelection" OWNER TO postgres;

--
-- Name: id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.id_seq OWNER TO postgres;

--
-- Name: Candidate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Candidate" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "BallotName" character varying,
    CONSTRAINT "can_BallotName_not_null" CHECK (("BallotName" IS NOT NULL))
);


ALTER TABLE public."Candidate" OWNER TO postgres;

--
-- Name: CandidateContest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CandidateContest" (
    "NumberElected" integer,
    "Office_Id" integer,
    "PrimaryParty_Id" integer,
    "Id" integer,
    CONSTRAINT "candcon_NumberElected_not_null" CHECK (("NumberElected" IS NOT NULL))
);


ALTER TABLE public."CandidateContest" OWNER TO postgres;

--
-- Name: CandidateSelection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CandidateSelection" (
    "Candidate_Id" integer,
    "Party_Id" integer,
    "Id" integer,
    CONSTRAINT "candsel_Candidate_Id_not_null" CHECK (("Candidate_Id" IS NOT NULL))
);


ALTER TABLE public."CandidateSelection" OWNER TO postgres;

--
-- Name: ComposingReportingUnitJoin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ComposingReportingUnitJoin" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "ParentReportingUnit_Id" integer,
    "ChildReportingUnit_Id" integer,
    CONSTRAINT "cruj_ChildReportingUnit_Id_not_null" CHECK (("ChildReportingUnit_Id" IS NOT NULL)),
    CONSTRAINT "cruj_ParentReportingUnit_Id_not_null" CHECK (("ParentReportingUnit_Id" IS NOT NULL))
);


ALTER TABLE public."ComposingReportingUnitJoin" OWNER TO postgres;

--
-- Name: Contest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contest" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Name" character varying,
    contest_type character varying,
    CONSTRAINT "contest_Name_not_null" CHECK (("Name" IS NOT NULL)),
    CONSTRAINT contest_contest_type_not_null CHECK ((contest_type IS NOT NULL))
);


ALTER TABLE public."Contest" OWNER TO postgres;

--
-- Name: CountItemStatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CountItemStatus" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Txt" character varying
);


ALTER TABLE public."CountItemStatus" OWNER TO postgres;

--
-- Name: CountItemType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CountItemType" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Txt" character varying
);


ALTER TABLE public."CountItemType" OWNER TO postgres;

--
-- Name: Election; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Election" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Name" character varying,
    "ElectionType_Id" integer,
    "OtherElectionType" character varying,
    CONSTRAINT "elec_ElectionType_Id_not_null" CHECK (("ElectionType_Id" IS NOT NULL)),
    CONSTRAINT "elec_Name_not_null" CHECK (("Name" IS NOT NULL))
);


ALTER TABLE public."Election" OWNER TO postgres;

--
-- Name: ElectionType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ElectionType" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Txt" character varying
);


ALTER TABLE public."ElectionType" OWNER TO postgres;

--
-- Name: IdentifierType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."IdentifierType" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Txt" character varying
);


ALTER TABLE public."IdentifierType" OWNER TO postgres;

--
-- Name: Office; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Office" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Name" character varying,
    "Description" character varying,
    "ElectionDistrict_Id" integer,
    CONSTRAINT "off_Name_not_null" CHECK (("Name" IS NOT NULL))
);


ALTER TABLE public."Office" OWNER TO postgres;

--
-- Name: Party; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Party" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Name" character varying,
    "Abbreviation" character varying,
    CONSTRAINT "party_Name_not_null" CHECK (("Name" IS NOT NULL))
);


ALTER TABLE public."Party" OWNER TO postgres;

--
-- Name: ReportingUnit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ReportingUnit" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Name" character varying,
    "ReportingUnitType_Id" integer,
    "OtherReportingUnitType" character varying,
    CONSTRAINT "ru_ReportingUnitType_Id_not_null" CHECK (("ReportingUnitType_Id" IS NOT NULL))
);


ALTER TABLE public."ReportingUnit" OWNER TO postgres;

--
-- Name: ReportingUnitType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ReportingUnitType" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Txt" character varying
);


ALTER TABLE public."ReportingUnitType" OWNER TO postgres;

--
-- Name: Selection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Selection" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL
);


ALTER TABLE public."Selection" OWNER TO postgres;

--
-- Name: VoteCount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VoteCount" (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    "Count" integer,
    "CountItemType_Id" integer,
    "OtherCountItemType" character varying,
    "ReportingUnit_Id" integer,
    "Contest_Id" integer,
    "Selection_Id" integer,
    "Election_Id" integer,
    "_datafile_Id" integer,
    CONSTRAINT "vc_Contest_Id_not_null" CHECK (("Contest_Id" IS NOT NULL)),
    CONSTRAINT "vc_CountItemType_Id_not_null" CHECK (("CountItemType_Id" IS NOT NULL)),
    CONSTRAINT "vc_Count_not_null" CHECK (("Count" IS NOT NULL)),
    CONSTRAINT "vc_Election_Id_not_null" CHECK (("Election_Id" IS NOT NULL)),
    CONSTRAINT "vc_ReportingUnit_Id_not_null" CHECK (("ReportingUnit_Id" IS NOT NULL)),
    CONSTRAINT "vc_Selection_Id_not_null" CHECK (("Selection_Id" IS NOT NULL)),
    CONSTRAINT "vc__datafile_Id_not_null" CHECK (("_datafile_Id" IS NOT NULL))
);


ALTER TABLE public."VoteCount" OWNER TO postgres;

--
-- Name: _datafile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._datafile (
    "Id" integer DEFAULT nextval('public.id_seq'::regclass) NOT NULL,
    short_name character varying,
    file_name character varying,
    download_date date,
    source character varying,
    note character varying,
    is_preliminary boolean,
    "ReportingUnit_Id" integer,
    "Election_Id" integer,
    created_at timestamp without time zone,
    CONSTRAINT "datafile_Election_Id_not_null" CHECK (("Election_Id" IS NOT NULL)),
    CONSTRAINT "datafile_ReportingUnit_Id_not_null" CHECK (("ReportingUnit_Id" IS NOT NULL)),
    CONSTRAINT datafile_download_date_not_null CHECK ((download_date IS NOT NULL)),
    CONSTRAINT datafile_file_name_not_null CHECK ((file_name IS NOT NULL)),
    CONSTRAINT datafile_note_not_null CHECK ((note IS NOT NULL)),
    CONSTRAINT datafile_short_name_not_null CHECK ((short_name IS NOT NULL)),
    CONSTRAINT datafile_source_not_null CHECK ((source IS NOT NULL))
);


ALTER TABLE public._datafile OWNER TO postgres;

--
-- Data for Name: BallotMeasureContest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BallotMeasureContest" ("Id", "ElectionDistrict_Id", "Election_Id") FROM stdin;
\.
COPY public."BallotMeasureContest" ("Id", "ElectionDistrict_Id", "Election_Id") FROM '$$PATH$$/3533.dat';

--
-- Data for Name: BallotMeasureSelection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BallotMeasureSelection" ("Name", "Id") FROM stdin;
\.
COPY public."BallotMeasureSelection" ("Name", "Id") FROM '$$PATH$$/3529.dat';

--
-- Data for Name: Candidate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Candidate" ("Id", "BallotName") FROM stdin;
\.
COPY public."Candidate" ("Id", "BallotName") FROM '$$PATH$$/3523.dat';

--
-- Data for Name: CandidateContest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CandidateContest" ("NumberElected", "Office_Id", "PrimaryParty_Id", "Id") FROM stdin;
\.
COPY public."CandidateContest" ("NumberElected", "Office_Id", "PrimaryParty_Id", "Id") FROM '$$PATH$$/3536.dat';

--
-- Data for Name: CandidateSelection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CandidateSelection" ("Candidate_Id", "Party_Id", "Id") FROM stdin;
\.
COPY public."CandidateSelection" ("Candidate_Id", "Party_Id", "Id") FROM '$$PATH$$/3530.dat';

--
-- Data for Name: ComposingReportingUnitJoin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ComposingReportingUnitJoin" ("Id", "ParentReportingUnit_Id", "ChildReportingUnit_Id") FROM stdin;
\.
COPY public."ComposingReportingUnitJoin" ("Id", "ParentReportingUnit_Id", "ChildReportingUnit_Id") FROM '$$PATH$$/3534.dat';

--
-- Data for Name: Contest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contest" ("Id", "Name", contest_type) FROM stdin;
\.
COPY public."Contest" ("Id", "Name", contest_type) FROM '$$PATH$$/3524.dat';

--
-- Data for Name: CountItemStatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CountItemStatus" ("Id", "Txt") FROM stdin;
\.
COPY public."CountItemStatus" ("Id", "Txt") FROM '$$PATH$$/3521.dat';

--
-- Data for Name: CountItemType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CountItemType" ("Id", "Txt") FROM stdin;
\.
COPY public."CountItemType" ("Id", "Txt") FROM '$$PATH$$/3522.dat';

--
-- Data for Name: Election; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Election" ("Id", "Name", "ElectionType_Id", "OtherElectionType") FROM stdin;
\.
COPY public."Election" ("Id", "Name", "ElectionType_Id", "OtherElectionType") FROM '$$PATH$$/3528.dat';

--
-- Data for Name: ElectionType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ElectionType" ("Id", "Txt") FROM stdin;
\.
COPY public."ElectionType" ("Id", "Txt") FROM '$$PATH$$/3520.dat';

--
-- Data for Name: IdentifierType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."IdentifierType" ("Id", "Txt") FROM stdin;
\.
COPY public."IdentifierType" ("Id", "Txt") FROM '$$PATH$$/3519.dat';

--
-- Data for Name: Office; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Office" ("Id", "Name", "Description", "ElectionDistrict_Id") FROM stdin;
\.
COPY public."Office" ("Id", "Name", "Description", "ElectionDistrict_Id") FROM '$$PATH$$/3532.dat';

--
-- Data for Name: Party; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Party" ("Id", "Name", "Abbreviation") FROM stdin;
\.
COPY public."Party" ("Id", "Name", "Abbreviation") FROM '$$PATH$$/3526.dat';

--
-- Data for Name: ReportingUnit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ReportingUnit" ("Id", "Name", "ReportingUnitType_Id", "OtherReportingUnitType") FROM stdin;
\.
COPY public."ReportingUnit" ("Id", "Name", "ReportingUnitType_Id", "OtherReportingUnitType") FROM '$$PATH$$/3527.dat';

--
-- Data for Name: ReportingUnitType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ReportingUnitType" ("Id", "Txt") FROM stdin;
\.
COPY public."ReportingUnitType" ("Id", "Txt") FROM '$$PATH$$/3518.dat';

--
-- Data for Name: Selection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Selection" ("Id") FROM stdin;
\.
COPY public."Selection" ("Id") FROM '$$PATH$$/3525.dat';

--
-- Data for Name: VoteCount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VoteCount" ("Id", "Count", "CountItemType_Id", "OtherCountItemType", "ReportingUnit_Id", "Contest_Id", "Selection_Id", "Election_Id", "_datafile_Id") FROM stdin;
\.
COPY public."VoteCount" ("Id", "Count", "CountItemType_Id", "OtherCountItemType", "ReportingUnit_Id", "Contest_Id", "Selection_Id", "Election_Id", "_datafile_Id") FROM '$$PATH$$/3535.dat';

--
-- Data for Name: _datafile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._datafile ("Id", short_name, file_name, download_date, source, note, is_preliminary, "ReportingUnit_Id", "Election_Id", created_at) FROM stdin;
\.
COPY public._datafile ("Id", short_name, file_name, download_date, source, note, is_preliminary, "ReportingUnit_Id", "Election_Id", created_at) FROM '$$PATH$$/3531.dat';

--
-- Name: id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id_seq', 37795, true);


--
-- Name: Candidate Candidate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Candidate"
    ADD CONSTRAINT "Candidate_pkey" PRIMARY KEY ("Id");


--
-- Name: ComposingReportingUnitJoin ComposingReportingUnitJoin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComposingReportingUnitJoin"
    ADD CONSTRAINT "ComposingReportingUnitJoin_pkey" PRIMARY KEY ("Id");


--
-- Name: Contest Contest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contest"
    ADD CONSTRAINT "Contest_pkey" PRIMARY KEY ("Id");


--
-- Name: CountItemStatus CountItemStatus_Txt_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CountItemStatus"
    ADD CONSTRAINT "CountItemStatus_Txt_key" UNIQUE ("Txt");


--
-- Name: CountItemStatus CountItemStatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CountItemStatus"
    ADD CONSTRAINT "CountItemStatus_pkey" PRIMARY KEY ("Id");


--
-- Name: CountItemType CountItemType_Txt_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CountItemType"
    ADD CONSTRAINT "CountItemType_Txt_key" UNIQUE ("Txt");


--
-- Name: CountItemType CountItemType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CountItemType"
    ADD CONSTRAINT "CountItemType_pkey" PRIMARY KEY ("Id");


--
-- Name: ElectionType ElectionType_Txt_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ElectionType"
    ADD CONSTRAINT "ElectionType_Txt_key" UNIQUE ("Txt");


--
-- Name: ElectionType ElectionType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ElectionType"
    ADD CONSTRAINT "ElectionType_pkey" PRIMARY KEY ("Id");


--
-- Name: Election Election_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Election"
    ADD CONSTRAINT "Election_pkey" PRIMARY KEY ("Id");


--
-- Name: IdentifierType IdentifierType_Txt_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IdentifierType"
    ADD CONSTRAINT "IdentifierType_Txt_key" UNIQUE ("Txt");


--
-- Name: IdentifierType IdentifierType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IdentifierType"
    ADD CONSTRAINT "IdentifierType_pkey" PRIMARY KEY ("Id");


--
-- Name: Office Office_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Office"
    ADD CONSTRAINT "Office_pkey" PRIMARY KEY ("Id");


--
-- Name: Party Party_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Party"
    ADD CONSTRAINT "Party_pkey" PRIMARY KEY ("Id");


--
-- Name: ReportingUnitType ReportingUnitType_Txt_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportingUnitType"
    ADD CONSTRAINT "ReportingUnitType_Txt_key" UNIQUE ("Txt");


--
-- Name: ReportingUnitType ReportingUnitType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportingUnitType"
    ADD CONSTRAINT "ReportingUnitType_pkey" PRIMARY KEY ("Id");


--
-- Name: ReportingUnit ReportingUnit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportingUnit"
    ADD CONSTRAINT "ReportingUnit_pkey" PRIMARY KEY ("Id");


--
-- Name: Selection Selection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Selection"
    ADD CONSTRAINT "Selection_pkey" PRIMARY KEY ("Id");


--
-- Name: VoteCount VoteCount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount_pkey" PRIMARY KEY ("Id");


--
-- Name: _datafile _datafile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._datafile
    ADD CONSTRAINT _datafile_pkey PRIMARY KEY ("Id");


--
-- Name: BallotMeasureContest bmcon_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureContest"
    ADD CONSTRAINT bmcon_no_dupes UNIQUE ("Id", "ElectionDistrict_Id", "Election_Id");


--
-- Name: BallotMeasureContest bmcon_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureContest"
    ADD CONSTRAINT bmcon_ux0 UNIQUE ("Id");


--
-- Name: BallotMeasureSelection bmsel_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureSelection"
    ADD CONSTRAINT bmsel_no_dupes UNIQUE ("Name", "Id");


--
-- Name: BallotMeasureSelection bmsel_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureSelection"
    ADD CONSTRAINT bmsel_ux0 UNIQUE ("Id");


--
-- Name: BallotMeasureSelection bmsel_ux1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureSelection"
    ADD CONSTRAINT bmsel_ux1 UNIQUE ("Name");


--
-- Name: Candidate can_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Candidate"
    ADD CONSTRAINT can_ux0 UNIQUE ("BallotName");


--
-- Name: CandidateContest candcon_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateContest"
    ADD CONSTRAINT candcon_no_dupes UNIQUE ("NumberElected", "Office_Id", "PrimaryParty_Id", "Id");


--
-- Name: CandidateContest candcon_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateContest"
    ADD CONSTRAINT candcon_ux0 UNIQUE ("Id");


--
-- Name: CandidateSelection candsel_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateSelection"
    ADD CONSTRAINT candsel_no_dupes UNIQUE ("Candidate_Id", "Party_Id", "Id");


--
-- Name: CandidateSelection candsel_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateSelection"
    ADD CONSTRAINT candsel_ux0 UNIQUE ("Id");


--
-- Name: CandidateSelection candsel_ux1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateSelection"
    ADD CONSTRAINT candsel_ux1 UNIQUE ("Candidate_Id", "Party_Id");


--
-- Name: Contest contest_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contest"
    ADD CONSTRAINT contest_ux0 UNIQUE ("Name", contest_type);


--
-- Name: _datafile datafile_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._datafile
    ADD CONSTRAINT datafile_no_dupes UNIQUE (short_name, file_name, download_date, source, note, is_preliminary, "ReportingUnit_Id", "Election_Id");


--
-- Name: Election elec_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Election"
    ADD CONSTRAINT elec_no_dupes UNIQUE ("Name", "ElectionType_Id", "OtherElectionType");


--
-- Name: Election elec_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Election"
    ADD CONSTRAINT elec_ux0 UNIQUE ("Name");


--
-- Name: Office off_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Office"
    ADD CONSTRAINT off_no_dupes UNIQUE ("Name", "Description", "ElectionDistrict_Id");


--
-- Name: Office off_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Office"
    ADD CONSTRAINT off_ux0 UNIQUE ("Name");


--
-- Name: Party party_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Party"
    ADD CONSTRAINT party_no_dupes UNIQUE ("Name", "Abbreviation");


--
-- Name: Party party_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Party"
    ADD CONSTRAINT party_ux0 UNIQUE ("Name");


--
-- Name: ReportingUnit ru_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportingUnit"
    ADD CONSTRAINT ru_no_dupes UNIQUE ("Name", "ReportingUnitType_Id", "OtherReportingUnitType");


--
-- Name: ReportingUnit ru_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportingUnit"
    ADD CONSTRAINT ru_ux0 UNIQUE ("Name");


--
-- Name: VoteCount vc_no_dupes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT vc_no_dupes UNIQUE ("Count", "CountItemType_Id", "OtherCountItemType", "ReportingUnit_Id", "Contest_Id", "Selection_Id", "Election_Id", "_datafile_Id");


--
-- Name: VoteCount vc_ux0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT vc_ux0 UNIQUE ("_datafile_Id", "Election_Id", "Contest_Id", "Selection_Id", "CountItemType_Id", "ReportingUnit_Id", "OtherCountItemType");


--
-- Name: BallotMeasureContest_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "BallotMeasureContest_parent" ON public."BallotMeasureContest" USING btree ("Id");


--
-- Name: BallotMeasureSelection_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "BallotMeasureSelection_parent" ON public."BallotMeasureSelection" USING btree ("Id");


--
-- Name: CandidateContest_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CandidateContest_parent" ON public."CandidateContest" USING btree ("Id");


--
-- Name: CandidateSelection_Candidate_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CandidateSelection_Candidate_Id_idx" ON public."CandidateSelection" USING btree ("Candidate_Id");


--
-- Name: CandidateSelection_Party_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CandidateSelection_Party_Id_idx" ON public."CandidateSelection" USING btree ("Party_Id");


--
-- Name: CandidateSelection_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CandidateSelection_parent" ON public."CandidateSelection" USING btree ("Id");


--
-- Name: Candidate_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Candidate_parent" ON public."Candidate" USING btree ("Id");


--
-- Name: ComposingReportingUnitJoin_ChildReportingUnit_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ComposingReportingUnitJoin_ChildReportingUnit_Id_idx" ON public."ComposingReportingUnitJoin" USING btree ("ChildReportingUnit_Id");


--
-- Name: ComposingReportingUnitJoin_ParentReportingUnit_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ComposingReportingUnitJoin_ParentReportingUnit_Id_idx" ON public."ComposingReportingUnitJoin" USING btree ("ParentReportingUnit_Id");


--
-- Name: ComposingReportingUnitJoin_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ComposingReportingUnitJoin_parent" ON public."ComposingReportingUnitJoin" USING btree ("Id");


--
-- Name: Contest_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Contest_parent" ON public."Contest" USING btree ("Id");


--
-- Name: CountItemStatus_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CountItemStatus_parent" ON public."CountItemStatus" USING btree ("Id");


--
-- Name: CountItemType_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CountItemType_parent" ON public."CountItemType" USING btree ("Id");


--
-- Name: ElectionType_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ElectionType_parent" ON public."ElectionType" USING btree ("Id");


--
-- Name: Election_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Election_parent" ON public."Election" USING btree ("Id");


--
-- Name: IdentifierType_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IdentifierType_parent" ON public."IdentifierType" USING btree ("Id");


--
-- Name: Office_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Office_parent" ON public."Office" USING btree ("Id");


--
-- Name: Party_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Party_parent" ON public."Party" USING btree ("Id");


--
-- Name: ReportingUnitType_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ReportingUnitType_parent" ON public."ReportingUnitType" USING btree ("Id");


--
-- Name: ReportingUnit_ReportingUnitType_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ReportingUnit_ReportingUnitType_Id_idx" ON public."ReportingUnit" USING btree ("ReportingUnitType_Id");


--
-- Name: ReportingUnit_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ReportingUnit_parent" ON public."ReportingUnit" USING btree ("Id");


--
-- Name: Selection_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Selection_parent" ON public."Selection" USING btree ("Id");


--
-- Name: VoteCount_Contest_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_Contest_Id_idx" ON public."VoteCount" USING btree ("Contest_Id");


--
-- Name: VoteCount_CountItemType_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_CountItemType_Id_idx" ON public."VoteCount" USING btree ("CountItemType_Id");


--
-- Name: VoteCount_Election_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_Election_Id_idx" ON public."VoteCount" USING btree ("Election_Id");


--
-- Name: VoteCount_OtherCountItemType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_OtherCountItemType_idx" ON public."VoteCount" USING btree ("OtherCountItemType");


--
-- Name: VoteCount_ReportingUnit_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_ReportingUnit_Id_idx" ON public."VoteCount" USING btree ("ReportingUnit_Id");


--
-- Name: VoteCount_Selection_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_Selection_Id_idx" ON public."VoteCount" USING btree ("Selection_Id");


--
-- Name: VoteCount__datafile_Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount__datafile_Id_idx" ON public."VoteCount" USING btree ("_datafile_Id");


--
-- Name: VoteCount_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "VoteCount_parent" ON public."VoteCount" USING btree ("Id");


--
-- Name: _datafile_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX _datafile_parent ON public._datafile USING btree ("Id");


--
-- Name: BallotMeasureContest BallotMeasureContest_ElectionDistrict_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureContest"
    ADD CONSTRAINT "BallotMeasureContest_ElectionDistrict_Id_fkey" FOREIGN KEY ("ElectionDistrict_Id") REFERENCES public."ReportingUnit"("Id");


--
-- Name: BallotMeasureContest BallotMeasureContest_Election_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureContest"
    ADD CONSTRAINT "BallotMeasureContest_Election_Id_fkey" FOREIGN KEY ("Election_Id") REFERENCES public."Election"("Id");


--
-- Name: BallotMeasureContest BallotMeasureContest_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureContest"
    ADD CONSTRAINT "BallotMeasureContest_Id_fkey" FOREIGN KEY ("Id") REFERENCES public."Contest"("Id");


--
-- Name: BallotMeasureSelection BallotMeasureSelection_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BallotMeasureSelection"
    ADD CONSTRAINT "BallotMeasureSelection_Id_fkey" FOREIGN KEY ("Id") REFERENCES public."Selection"("Id");


--
-- Name: CandidateContest CandidateContest_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateContest"
    ADD CONSTRAINT "CandidateContest_Id_fkey" FOREIGN KEY ("Id") REFERENCES public."Contest"("Id");


--
-- Name: CandidateContest CandidateContest_Office_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateContest"
    ADD CONSTRAINT "CandidateContest_Office_Id_fkey" FOREIGN KEY ("Office_Id") REFERENCES public."Office"("Id");


--
-- Name: CandidateContest CandidateContest_PrimaryParty_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateContest"
    ADD CONSTRAINT "CandidateContest_PrimaryParty_Id_fkey" FOREIGN KEY ("PrimaryParty_Id") REFERENCES public."Party"("Id");


--
-- Name: CandidateSelection CandidateSelection_Candidate_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateSelection"
    ADD CONSTRAINT "CandidateSelection_Candidate_Id_fkey" FOREIGN KEY ("Candidate_Id") REFERENCES public."Candidate"("Id");


--
-- Name: CandidateSelection CandidateSelection_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateSelection"
    ADD CONSTRAINT "CandidateSelection_Id_fkey" FOREIGN KEY ("Id") REFERENCES public."Selection"("Id");


--
-- Name: CandidateSelection CandidateSelection_Party_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CandidateSelection"
    ADD CONSTRAINT "CandidateSelection_Party_Id_fkey" FOREIGN KEY ("Party_Id") REFERENCES public."Party"("Id");


--
-- Name: ComposingReportingUnitJoin ComposingReportingUnitJoin_ChildReportingUnit_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComposingReportingUnitJoin"
    ADD CONSTRAINT "ComposingReportingUnitJoin_ChildReportingUnit_Id_fkey" FOREIGN KEY ("ChildReportingUnit_Id") REFERENCES public."ReportingUnit"("Id");


--
-- Name: ComposingReportingUnitJoin ComposingReportingUnitJoin_ParentReportingUnit_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ComposingReportingUnitJoin"
    ADD CONSTRAINT "ComposingReportingUnitJoin_ParentReportingUnit_Id_fkey" FOREIGN KEY ("ParentReportingUnit_Id") REFERENCES public."ReportingUnit"("Id");


--
-- Name: Election Election_ElectionType_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Election"
    ADD CONSTRAINT "Election_ElectionType_Id_fkey" FOREIGN KEY ("ElectionType_Id") REFERENCES public."ElectionType"("Id");


--
-- Name: Office Office_ElectionDistrict_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Office"
    ADD CONSTRAINT "Office_ElectionDistrict_Id_fkey" FOREIGN KEY ("ElectionDistrict_Id") REFERENCES public."ReportingUnit"("Id");


--
-- Name: ReportingUnit ReportingUnit_ReportingUnitType_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ReportingUnit"
    ADD CONSTRAINT "ReportingUnit_ReportingUnitType_Id_fkey" FOREIGN KEY ("ReportingUnitType_Id") REFERENCES public."ReportingUnitType"("Id");


--
-- Name: VoteCount VoteCount_Contest_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount_Contest_Id_fkey" FOREIGN KEY ("Contest_Id") REFERENCES public."Contest"("Id");


--
-- Name: VoteCount VoteCount_CountItemType_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount_CountItemType_Id_fkey" FOREIGN KEY ("CountItemType_Id") REFERENCES public."CountItemType"("Id");


--
-- Name: VoteCount VoteCount_Election_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount_Election_Id_fkey" FOREIGN KEY ("Election_Id") REFERENCES public."Election"("Id");


--
-- Name: VoteCount VoteCount_ReportingUnit_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount_ReportingUnit_Id_fkey" FOREIGN KEY ("ReportingUnit_Id") REFERENCES public."ReportingUnit"("Id");


--
-- Name: VoteCount VoteCount_Selection_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount_Selection_Id_fkey" FOREIGN KEY ("Selection_Id") REFERENCES public."Selection"("Id");


--
-- Name: VoteCount VoteCount__datafile_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VoteCount"
    ADD CONSTRAINT "VoteCount__datafile_Id_fkey" FOREIGN KEY ("_datafile_Id") REFERENCES public._datafile("Id");


--
-- Name: _datafile _datafile_Election_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._datafile
    ADD CONSTRAINT "_datafile_Election_Id_fkey" FOREIGN KEY ("Election_Id") REFERENCES public."Election"("Id");


--
-- Name: _datafile _datafile_ReportingUnit_Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._datafile
    ADD CONSTRAINT "_datafile_ReportingUnit_Id_fkey" FOREIGN KEY ("ReportingUnit_Id") REFERENCES public."ReportingUnit"("Id");


--
-- PostgreSQL database dump complete
--

